package undo.redo;

public abstract class COUndoRedo {

}
