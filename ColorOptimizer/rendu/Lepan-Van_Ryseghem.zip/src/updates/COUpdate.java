package updates;

import core.COView;

public abstract class COUpdate {
	
	public abstract void updateOn(COView view);
}
